var likes1 = document.querySelector('.topofbox1 span')

function increaseLikes1() {
    likes1.innerText++;
}

var likes2 = document.querySelector('.topofbox2 span')

function increaseLikes2() {
    likes2.innerText++;
}

var likes3 = document.querySelector('.topofbox3 span')

function increaseLikes3() {
    likes3.innerText++;
}