function giveAlert(){
    alert("Ninja was liked")
}

function removeButton(element){
    element.remove();
}

function Logout(element){
    element.innerText = "Logout"
}